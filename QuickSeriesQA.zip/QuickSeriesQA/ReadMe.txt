IDE Used: IntelliJ IDEA 
OS: Windows 10
Dependencies:
-JDK
https://www.oracle.com/ca-en/java/technologies/javase-downloads.html
-JRE
https://www.oracle.com/ca-en/java/technologies/javase-downloads.html
-Selenium 
https://www.selenium.dev/downloads/
-TestNG
https://mvnrepository.com/artifact/org.testng/testng/7.1.0 (download the jar)
-Chrome Driver
https://chromedriver.chromium.org/downloads
-Guice
https://github.com/google/guice/wiki/Guice422

Steps:
1. Install IntelliJ, JDK and JRE, if not installed already.
2. Add JAVA_HOME path in the System Environment Variables.
3. Add the Selenium, TestNG and Guice jar files in File>Project Structure>Libraries and enable them in the File>Project Structure>Modules>Dependencies.
4. Update the chromepath variable in contactUs.java to the location of the chrome driver.
5. Open testng.xml and run 
6. To generate report, go to Run from the toolbar, and then Edit Configurations>select testng.xml>Listeners. Click + (Add)
	-search for EmailableReporter and click "Ok"
	-search for FailedReporter and click "Ok"
	-test-output folder should be created after running the test, where the reports can be found. 