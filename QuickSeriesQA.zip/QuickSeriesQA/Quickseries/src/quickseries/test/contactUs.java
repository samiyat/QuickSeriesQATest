package quickseries.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import page.object.contactUsPage;
import java.util.List;

import java.util.concurrent.TimeUnit;

public class contactUs {
    WebDriver driver;
    String chromePath;
    contactUsPage conUs;
    WebDriverWait wait;

    @BeforeMethod
    public void launchURL(){
        chromePath = "C:\\Users\\intya\\Documents\\selenium\\chrome\\chromedriver.exe";
        System.setProperty("webdriver.chrome.driver",chromePath);
        driver = new ChromeDriver();
        driver.navigate().to("https://www.quickseries.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
    }
    @Test
    public  void contactUsLandingPage(){
        conUs= new contactUsPage(driver);
        conUs.contactUsPageLanding();
        //few validations on contact us page display
        Assert.assertEquals(driver.getTitle(),"Get in touch! - QuickSeries");
        driver.findElement(By.xpath("//h1[contains(text(),'Get in touch')]")).isDisplayed();
        driver.findElement(By.xpath("//h3[contains(text(),'Contact us')]")).isDisplayed();
    }
    @Test
    public void allRequiredEmpty(){
        conUs = new contactUsPage(driver);
        conUs.contactUsPageLanding();
        conUs.enterFirstName("");
        conUs.enterLastName("");
        conUs.enterEmail("");
        conUs.enterCompany("");
        conUs.enterPhoneNumber("");
        conUs.submit();

        // verify that error message for each required field is displayed
        List <WebElement> fieldError= driver.findElements(By.xpath("//span[@class='wpcf7-not-valid-tip']"));
        int errorCount = fieldError.size();
        //6th error is for recaptcha, ideally disabled for testing/staging environment where automated tests are running
        Assert.assertEquals(errorCount,6);
        //error for each field will be covered in other tests, so just validating one message in this one
        Assert.assertEquals(fieldError.get(0).getText(),"The field is required.");
        Assert.assertEquals(driver.findElement(By.xpath("//div[@class='wpcf7-response-output wpcf7-display-none wpcf7-validation-errors']")).getText(),"One or more fields have an error. Please check and try again.");

    }
    @Test
    public void emptyFirstName(){

        conUs = new contactUsPage(driver);
        conUs.contactUsPageLanding();
        conUs.enterFirstName("");
        conUs.enterLastName("Doe");
        conUs.enterEmail("test@email.com");
        conUs.enterCompany("ABC");
        conUs.enterPhoneNumber("123-456-7890");
        conUs.submit();

        wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'First Name *')]")));

        // verify error messages are displayed
        Assert.assertEquals(driver.findElement(By.xpath("//span[@class='wpcf7-not-valid-tip']")).getText(),"The field is required.");
        Assert.assertEquals(driver.findElement(By.xpath("//div[@class='wpcf7-response-output wpcf7-display-none wpcf7-validation-errors']")).getText(),"One or more fields have an error. Please check and try again.");
    }
    @Test
    public void emptyLastName(){

        conUs = new contactUsPage(driver);
        conUs.contactUsPageLanding();
        conUs.enterFirstName("John");
        conUs.enterLastName("");
        conUs.enterEmail("test@email.com");
        conUs.enterCompany("ABC");
        conUs.enterPhoneNumber("123-456-7890");
        conUs.submit();
        wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Last Name *')]")));

        //verify error messages are displayed
        Assert.assertEquals(driver.findElement(By.xpath("//span[@class='wpcf7-not-valid-tip']")).getText(),"The field is required.");
        Assert.assertEquals(driver.findElement(By.xpath("//div[@class='wpcf7-response-output wpcf7-display-none wpcf7-validation-errors']")).getText(),"One or more fields have an error. Please check and try again.");

    }
    @Test
    public void emptyEmail(){
        conUs = new contactUsPage(driver);
        conUs.contactUsPageLanding();
        conUs.enterFirstName("John");
        conUs.enterLastName("Doe");
        conUs.enterEmail("");
        conUs.enterCompany("ABC");
        conUs.enterPhoneNumber("123-456-7890");
        conUs.submit();

        wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Email Address *')]")));

        //verify error messages are displayed
        Assert.assertEquals(driver.findElement(By.xpath("//span[@class='wpcf7-not-valid-tip']")).getText(),"The field is required.");
        Assert.assertEquals(driver.findElement(By.xpath("//div[@class='wpcf7-response-output wpcf7-display-none wpcf7-validation-errors']")).getText(),"One or more fields have an error. Please check and try again.");
    }
    @Test
    public void emptyCompany(){
        conUs = new contactUsPage(driver);
        conUs.contactUsPageLanding();
        conUs.enterFirstName("John");
        conUs.enterLastName("Doe");
        conUs.enterEmail("test@email.com");
        conUs.enterCompany("");
        conUs.enterPhoneNumber("123-456-7890");
        conUs.submit();

        wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Organization/Corporation *')]")));

        //verify error messages are displayed
        Assert.assertEquals(driver.findElement(By.xpath("//span[@class='wpcf7-not-valid-tip']")).getText(),"The field is required.");
        Assert.assertEquals(driver.findElement(By.xpath("//div[@class='wpcf7-response-output wpcf7-display-none wpcf7-validation-errors']")).getText(),"One or more fields have an error. Please check and try again.");
    }
    @Test
    public void emptyPhoneNumber(){
        conUs = new contactUsPage(driver);
        conUs.contactUsPageLanding();
        conUs.enterFirstName("John");
        conUs.enterLastName("Doe");
        conUs.enterEmail("test@email.com");
        conUs.enterCompany("ABC");
        conUs.enterPhoneNumber("");
        conUs.submit();

        wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Phone Number *')]")));

        //verify error messages are displayed
        Assert.assertEquals(driver.findElement(By.xpath("//span[@class='wpcf7-not-valid-tip']")).getText(),"The field is required.");
        Assert.assertEquals(driver.findElement(By.xpath("//div[@class='wpcf7-response-output wpcf7-display-none wpcf7-validation-errors']")).getText(),"One or more fields have an error. Please check and try again.");
    }


    @AfterMethod
    public void tearDown(){
        driver.quit();
    }

}
