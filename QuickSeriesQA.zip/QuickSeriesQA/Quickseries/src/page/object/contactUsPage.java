package page.object;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class contactUsPage {
    WebDriver driver;
    public contactUsPage(WebDriver driver){
        this.driver = driver;
    }
    public void contactUsPageLanding(){
        //verify user is on landing page
        Assert.assertEquals(driver.getTitle(),"Community Content Delivery Experts – QuickSeries Publishing");

        //click contact us
        driver.findElement(By.xpath("//a[@href='https://www.quickseries.com/contact-us/']")).click();
    }
    public void enterFirstName(String firstName){
        driver.findElement(By.id("inputFirstName")).sendKeys(firstName);
    }
    public void enterLastName(String lastName){
        driver.findElement(By.id("inputLastName")).sendKeys(lastName);
    }
    public void enterCompany(String company){
        driver.findElement(By.id("inputCompany")).sendKeys(company);
    }
    public void enterPhoneNumber(String phn){
        driver.findElement(By.id("inputTelephone")).sendKeys(phn);
    }
    public void enterEmail(String email){
        driver.findElement(By.id("inputEmail")).sendKeys(email);
    }
    public void submit(){
        driver.findElement(By.xpath("//input[@type='submit']")).click();
    }

}
